#!/usr/bin/env bash
moduleName="FixedModule"
moduleGroup="FreeIntro"
testDesc="Page Matched"
matchRule="Custom storefront page"
pageId="fixmodulesolution-storefront-page"

test_html_page_match "$moduleName" "$moduleGroup" "$testDesc" "$pageId" "$matchRule"