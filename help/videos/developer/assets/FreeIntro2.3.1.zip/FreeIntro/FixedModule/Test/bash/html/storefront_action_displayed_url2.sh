#!/usr/bin/env bash
moduleName="FixedModule"
moduleGroup="FreeIntro"
testDesc="Page Matched"
pageId="fixmodulesolution/storefront/page"
matchRule="Custom storefront page"

test_html_page_match "$moduleName" "$moduleGroup" "$testDesc" "$pageId" "$matchRule"