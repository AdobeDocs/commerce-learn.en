#Magento2 Free Intro Labs  

Exercise #1. CLI.
 1. Find out which module your Magento installation is running.
 2. Switch application "run mode" into developer.
 3. List all M2 modules installed in your app.
 4. Create new admin account using console.
 
 Exercise #2. Composer.
 1. Check that you have latest version of Composer.
 2. Make sure you have no issues once composer.json been modified.
 3. Find dependencies which are out of the date.
 4. Update one dependency of your choice.
 5. Add new dependency to the project.
 
 Exercise #3. Fix broken module.
 1. Fix provided broken module. Make it works.
 2. Fix 3 issues it has.
 3. After that, make router class within module works by fixing an issue.

 Exercise #4. Compose unit test. 
 1. Create simple unit test for router from Exercise #3.
 2. Run it check it works.
 3. Test whole platform by running the set of unit test goes with the project out of the box.
 
 Exercise #5. Create admin page.
 1. Make sure you have configured routes.xml acl.xml menu.xml files in the right way.
 2. Make sure you've got action class placed under Controller/Adminhtml folder.
 3. Make sure your action class extends Backend/App/Action.
 4. Make sure your action class implements execute() method and has once const sets acl resource to the action. 